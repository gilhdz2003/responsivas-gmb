# Templates PDF

Esta carpeta contiene los PDFs de ejemplo que se usan actualmente en Grupo MB para las responsivas.

## Archivos

Aquí se colocarán los 6 PDFs muestra que el usuario proporcionará:

- [ ] Responsiva Computadora 1
- [ ] Responsiva Computadora 2
- [ ] Responsiva Computadora 3
- [ ] Responsiva Celular 1
- [ ] Responsiva Celular 2
- [ ] Responsiva Celular 3

## Uso

Estos PDFs servirán como base para:
1. Diseñar el layout de las responsivas digitales
2. Extraer el contenido textual para los templates
3. Definir los campos dinámicos (nombre, empleado, fecha, etc.)
