<?php
/**
 * GMB Responsivas - Database Credentials
 *
 * CONFIGURACIÓN DE BASE DE DATOS
 *
 * Este archivo contiene las credenciales de conexión a la base de datos.
 *
 * INSTRUCCIONES:
 * 1. En Hostinger, crea una base de datos MySQL desde el panel
 * 2. Importa el schema desde config/schema.sql
 * 3. Actualiza los valores abajo con tus credenciales reales
 *
 * SEGURIDAD:
 * - Este archivo NO debe ser accesible desde el navegador
 * - .gitignore está configurado para ignorarlo
 * - No commits de credenciales reales al repositorio
 */

return [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'port' => getenv('DB_PORT') ?: '3306',
    'database' => getenv('DB_NAME') ?: 'grupomb_responsivas',
    'username' => getenv('DB_USER') ?: '',     // CAMBIAR
    'password' => getenv('DB_PASS') ?: '',     // CAMBIAR
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
];
